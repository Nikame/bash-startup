# .bashrc

# This file is created when the VM is provisioned.  It will be overwritten every
# time the vm is reprovisioned.  If you want to customize or add anything here,
# do it instead in ~/.personal_bashrc.  That is sourced at the end of this file,
# so it has the ability to override anything that is done here.  That file won't
# be changed by re-provisioning.

# Keep this line first, so we start with the global definitions.
if [ -f /etc/bashrc ]; then
    # typically observed on RedHat derivative distros
    . /etc/bashrc
elif [ -f /etc/bash.bashrc ]; then
    # typically observed on Debian derivative distros
    . /etc/bash.bashrc
fi

PS1='\[\e[1;34m\]\W $( if [ $? -eq 0 ]; then echo "\[\e[0;32m\]:)"; else echo "\[\e[0;31m\]:("; fi ) \[\e[0m\]'
export EDITOR=/usr/bin/vim
export LESS='-R -M --shift 5'
# Fix for ssh-agent issue "Permission Denied" on git pull
export SSH_AUTH_SOCK=0
export GROOVY_HOME=/usr/local/groovy/latest
export DISPLAY=:0.0

. ~/.path

alias dbeaver="xterm -e /opt/dbeaver/dbeaver -data ~/.dbeaver &"
alias eclipse="xterm -e eclipse &"
alias sqldeveloper="xterm -e sqldeveloper &"
alias firefox='xterm -e firefox &'
alias chrome='xterm -e google-chrome &'
alias kompare='xterm -e kompare &'
alias kdiff3='xterm -e kdiff3 &'

#container env related function and alias.
function setup_env() { . ~/bin/wnc_container_env_setup.sh "$@"; }
alias setup_build='~/bin/wnc_container_build_setup'
alias get_tags='~/bin/get_tags.sh'

# wnc_env - initializes Windchill development environment
function wnc_env() { . ~/bin/windchill_env.sh "$@"; }

# wnc_shell - initializes "Windchill Shell" env
function wnc_shell() {
    # optional param to init WT_HOME if its not already set
    if [[ -n "$1" ]]; then
        WT_HOME=/opt/ptc/$1/Windchill
    fi
    if [[ -z "$WT_HOME" ]]; then
        echo "WT_HOME unknown. Pass in the name of a windchill install."
        echo "Example: wnc_shell berlin_11"
    else
        # using eval command instead of windchill shell command so the PATH is correct
        # (PATH setup by windchill shell command is always overriden by .path script)
        eval `$WT_HOME/bin/windchill eval`
        echo "Windchill Shell env initialized."
        echo "WT_HOME=$WT_HOME"
    fi
}

alias start_oracle='sudo systemctl start oracle.service'
alias stop_oracle='sudo systemctl stop oracle.service'

export getip=$(hostname -I | cut -d" " -f1)
export PSI_SKIP_OS_CHECK=1

alias start_keycloak='xterm -e "export JAVA_HOME=/opt/jdk11 && /opt/ptc/keycloak-21.0.1/bin/kc.sh start-dev --http-port=18080" &'
alias start_ds='/opt/ptc/WindchillDS/server/bin/start-ds'
alias stop_ds='/opt/ptc/WindchillDS/server/bin/stop-ds'
alias k='kubectl'
alias kg='kubectl get'
alias kd='kubectl describe'
alias kl='kubectl logs'
alias get_ip='echo $getip'

# setup nvm
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

# User specific aliases and functions
if [ -d ~/.bashrc.d ]; then
        for rc in ~/.bashrc.d/*; do
                if [ -f "$rc" ]; then
                        . "$rc"
                fi
        done
fi

# export PYENV_ROOT="$HOME/.pyenv"
# export PATH="$PYENV_ROOT/bin:$PATH"
# eval "$(pyenv init -)"


# Keep this line last, so it has the ability to override anything.
[[ -f ~/.personal_bashrc ]] && . ~/.personal_bashrc
true
