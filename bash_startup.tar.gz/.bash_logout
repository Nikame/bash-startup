# ~/.bash_logout

# This file is created when the VM is provisioned.  It will be overwritten every
# time the vm is reprovisioned.  If you want to add anything here, do it instead
# in ~/.personal_bash_logout.  That file won't be changed by re-provisioning.

[[ -f ~/.personal_bash_logout ]] && . ~/.personal_bash_logout
true
