# load Python virtualenvwrapper automatically
source /d/Users/nkamerka/Software/Python/Python36/Scripts/virtualenvwrapper.sh

 workon superlists
