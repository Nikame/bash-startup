# .bash_profile

# This file is created when the VM is provisioned.  It will be overwritten every
# time the vm is reprovisioned.  If you want to add anything here, do it instead
# in ~/.personal_bash_profile.  That file won't be changed by re-provisioning.

[[ -f ~/.bashrc ]] && . ~/.bashrc

[[ -f ~/.personal_bash_profile ]] && . ~/.personal_bash_profile
true

# bun
export BUN_INSTALL="$HOME/.bun"
export PATH="$BUN_INSTALL/bin:$PATH"
